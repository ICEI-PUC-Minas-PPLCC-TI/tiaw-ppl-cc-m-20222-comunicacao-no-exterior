function leDados() {
    //verifica se existe algo no localStorage
    let strDados = localStorage.getItem('db');
    let objDados = {}; //cria um objeto vazio
  
    if (strDados) {
        objDados = JSON.parse(strDados); //transforma a string strDados do localStorage em um objeto
    } //if
    else {
        // objDados é um objeto JSON
        objDados = {
            // idiomas é um array que guarda objetos
            idiomas: [
            {
                id: 0,
                idioma: "Alemão",
                img: "Assets/Images/germany.png",
                link: "alemao"
            },
            {
                id: 1,
                idioma: "Inglês",
                img: "Assets/Images/united-states.png",
                link: "ingles"
            },
            {
                id: 2,
                idioma: "Chinês",
                img: "Assets/Images/china.png",
                link: "chines"
            },
            {
                id: 3,
                idioma: "Dinamarquês",
                img: "Assets/Images/denmark.png",
                link: "alemao"
            },
            {
                id: 4,
                idioma: "Espanhol",
                img: "Assets/Images/spain.png",
                link: "espanhol"
            },
            {
                id: 5,
                idioma: "Francês",
                img: "Assets/Images/france.png",
                link: "alemao"
            },
            {
                id: 6,
                idioma: "Galego",
                img: "Assets/Images/pais-de-gales.png",
                link: "alemao"
            },
            ]
        } //objDados
    } //else
    return objDados;
}
  
function salvaDados(dados) {
    //transforma o objeto JSON dados recebido de localStorage em uma string
    localStorage.setItem('db', JSON.stringify(dados));
}
  
function imprimeDados() {
    let listaIdiomas = document.getElementById('idiomas');
    //listaIdiomas (local) da função passa a ser o elemento de id idiomas do html
  
    let strHtml = ''; //cria uma string vazia
  
    let objDados = leDados(); //executa a função leDados()
    salvaDados(objDados);
  
    strHtml += `<ul class="list-group list-group-flush">`; //abre a ul
  
    //preenche a ul com os li's
    for (let i = 0; i < objDados.idiomas.length; i++) {
      strHtml += `<li class="list-group-item">
                          <a href="lin${i}.html">
                              <img src="${objDados.idiomas[i].img}" class="rounded-circle" alt="idioma">
                              <span class="categoria-text">${objDados.idiomas[i].idioma}</span>
                          </a>
                      </li>`
      //console.log(objDados.paises[i].codigo);
      //console.log(objDados.idiomas[i].idioma);
    }
  
    strHtml += `</ul>`; //fecha a ul
  
    listaIdiomas.innerHTML = strHtml;
    //o código html da div de id categorias passa a ser strHtml, que é a string que acabou de ser preenchida
}