
//var objDados = {Detalhes: [ {usuario: "João da Silva"}, {pNome: "João"}, {uNome: "da Silva"}, {email: "exemplo@ex.com"}, {telefone: "99999999999"}, {nascimento: "00/00/0000"} ] };
//var objDados = {Detalhes: [ { usuario: "João da Silva", pNome: "João", uNome: "da Silva", email: "exemplo@ex.com", telefone: "99999999999", nascimento: "00/00/0000" } ] };
//console.log(objDados)

function leDados () {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = {Detalhes: [ { usuario: "João da Silva", pNome: "João", uNome: "da Silva", email: "exemplo@ex.com", telefone: "99999999999", nascimento: "00/00/0000" } ] };
    }

    return objDados;
}

console.log(leDados())

function preencheDados () {
    let objDados = leDados();
    document.getElementById('inputUsername').value = objDados.Detalhes[0].usuario;
    document.getElementById('inputFirstName').value = objDados.Detalhes[0].pNome;
    document.getElementById('inputLastName').value = objDados.Detalhes[0].uNome;
    document.getElementById('inputEmailAddress').value = objDados.Detalhes[0].email;
    document.getElementById('inputPhone').value = objDados.Detalhes[0].telefone;
    document.getElementById('inputBirthday').value = objDados.Detalhes[0].nascimento;
}

function salvarAlteracoes () {
    let objDados = leDados();
    objDados.Detalhes[0].usuario = document.getElementById('inputUsername').value;
    objDados.Detalhes[0].pNome = document.getElementById('inputFirstName').value;
    objDados.Detalhes[0].uNome = document.getElementById('inputLastName').value;
    objDados.Detalhes[0].email = document.getElementById('inputEmailAddress').value;
    objDados.Detalhes[0].telefone = document.getElementById('inputPhone').value;
    objDados.Detalhes[0].nascimento = document.getElementById('inputBirthday').value;
    localStorage.setItem ('db', JSON.stringify (objDados));
    location.href='../perfil/perfil.html';

}

preencheDados ();

// Configura os botões
btn_salvar.onclick = () => salvarAlteracoes ();
//document.getElementById ('btn_salvar').addEventListener ('click', salvarAlteracoes);
