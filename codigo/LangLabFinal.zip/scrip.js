// declara um conjunto inicial de contatos
var db_contatos_inicial = {
  "data": [
    {
      "id": 1,
      "categoria": "Animal",
      "sobre": "Os animais são principais seres vivos do mundo, é importante conhecer eles para obter mais conhecimentos!",
      "ingles":"Animal",
      "espanhol":"Animal",
      "chines":"动物",
      "alemao":"Tier",
    },
    {
      "id": 2,
      "categoria": "Banheiro",
      "sobre":"Usamos banheiro todos os dias, é importante conhecer um pouco mais sobre ele!",
      "ingles":"Bathroom",
      "espanhol":"Baño",
      "chines":"厕所",
      "alemao":"Toilette",
    },
    {
      "id": 3,
      "categoria": "Casa",
      "sobre":"Uma grande parte do nosso tempo fica em casa, vamos aprender mais sobre ele?",
      "ingles":"House",
      "espanhol":"Casa",
      "chines":"家",
      "alemao":"Haus",
    },
    {
      "id": 4,
      "categoria": "Direção",
      "sobre":"Andamos na rua quase todos dias, vamos saber um pouco sobre a direção?",
      "ingles":"Direction",
      "espanhol":"Dirección",
      "chines":"方向",
      "alemao":"Richtung",
    },
    {
      "id": 5,
      "categoria": "Emergência",
      "sobre": "Em situação de emergência, é importante de você saber o significado das palavras principais!",
      "ingles":"Emergency",
      "espanhol":"Emergencia",
      "chines":"紧急情况",
      "alemao":"Notfall",
    },
    {
      "id": 6,
      "categoria": "Esporte",
      "sobre":"A esporte é importante para saúde, vamos conhecer um pouco sobre ele!",
      "ingles":"Sport",
      "espanhol":"Deporte",
      "chines":"运动",
      "alemao":"Sport",
    },
    {
      "id": 7,
      "categoria": "Família",
      "sobre":"A família é composto de pessoas mais importantes para cada um, vamos conhecer eles em outros linguagens?",
      "ingles":"Family",
      "espanhol":"Familia",
      "chines":"家庭",
      "alemao":"Familie",
    },
    {
      "id": 8,
      "categoria": "Hospital",
      "sobre": "Saber um pouco do significado das principais palavras sobre o hospital é importante em sitação de risco. ",
      "ingles":"Hospital",
      "espanhol":"Hospital",
      "chines":"医院",
      "alemao":"Krankenhaus",
    },
  ]
}

// Caso os dados já estejam no Local Storage, caso contrário, carrega os dados iniciais
var db = JSON.parse(localStorage.getItem('db_contato'));
if (!db) {
  db = db_contatos_inicial
};

function updateContato(id, contato) {
  // Localiza o indice do objeto a ser alterado no array a partir do seu ID
  let index = db.data.map(obj => obj.id).indexOf(id);

  // Altera os dados do objeto no array
  db.data[index].cidade = contato.cidade,
    db.data[index].categoria = contato.categoria,


    displayMessage("Contato alterado com sucesso");

  // Atualiza os dados no Local Storage
  localStorage.setItem('db_contato', JSON.stringify(db));
}
