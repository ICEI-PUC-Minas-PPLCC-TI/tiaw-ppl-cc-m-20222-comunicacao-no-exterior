var dados =
{
  ingles:
  {
    filmes:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/AAAABbFI2wcwiGkHDdGWaw58hWgLETOBsbqqv6GbKnZFn3s_Y4fjw0Ys9DNYD5txnfV3oj9tgsBeaSnPcBOwQqQnpHVqHeQr9FtvVzaL.jpg" class="d-block w-100" id="banner" alt="Breaking Bad">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>BREAKING BAD</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/MV5BMjk3NTYyMzc4Nl5BMl5BanBnXkFtZTcwODU3ODMzMw@@._V1_.jpg" class="d-block w-100" id="banner" alt="Clube da luta">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>CLUBE DA LUTA</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/whiplash1.jpg" class="d-block w-100" id="banner" alt="Whiplash">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>WHIPLASH</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>',
    livros:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/190801105352-01-uk-harry-potter-first-edition-sale.jpg" class="d-block w-100" id="banner" alt="Harry Potter">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>HARRY POTTER</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/images.jpg" class="d-block w-100" id="banner" alt="O senhor dos aneis">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>O SENHOR DOS ANÉIS</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/narnialucia.jpg" class="d-block w-100" id="banner" alt="Narnia">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>NARNIA</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>',
    instagrans:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/9gag-og.png" class="d-block w-100" id="banner" alt="9gag">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>9GAG</h5>' +
      '<p>@9gag</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/25CNN-videoSixteenByNine3000.jpg" class="d-block w-100" id="banner" alt="CNN">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>CNN</h5>' +
      '<p>@cnn</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>'
  },
  frances:
  {
    filmes:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/bea2d9658feb9352eac9025e1dc1ce7f2bb1e286-1140x570.jpg" class="d-block w-100" id="banner" alt="Eu não sou um homem fácil">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>EU NÃO SOU UM HOMEM FÁCIL</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/os-nomes-do-amor.jpg" class="d-block w-100" id="banner" alt="Os nomes do amor">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>OS NOMES DO AMOR</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/entre-os-muros-da-escola.jpg" class="d-block w-100" id="banner" alt="Entre os muros da escola">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>ENTRE OS MUROS DA ESCOLA</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>',
    livros:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/Le-Petit-Prince-Dessin-400x400.jpg" class="d-block w-100" id="banner" alt="O pequeno principe">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>O PEQUENO PRINCIPE</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/Emile-Bayard-Cosette-balayant-charcoal-gouache-pastel-1879_Q320.jpg" class="d-block w-100" id="banner" alt="os miseraveis">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>OS MISERÁVEIS</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/a-bela-e-a-fera-historia-original-1170x658.jpg" class="d-block w-100" id="banner" alt="A bela e a fera">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>A BELA E A FERA</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>',
    instagrans:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/bandeira-da-franca-1200x900.jpg" class="d-block w-100" id="banner" alt="memes in french">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>MEMES IN FRENCH</h5>' +
      '<p>@memes.in.french</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/maxresdefault.jpg" class="d-block w-100" id="banner" alt="France 24">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>FRANCE 24</h5>' +
      '<p>@france24</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>'
  },
  espanhol:
  {
    filmes:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/AAAABVCVp9SZOtwxMFYqpwqVBwYAxb9qfk2VGP2qG-DPkhzecNaeDtU4Puqkotdaeg2wPobcQRUrIsiS9tHRGHnia9l0NNzc3oFy6JIg.jpg" class="d-block w-100" id="banner" alt="O poço">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>O POÇO</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/la-casa-de-papel-cancelada-750x430.jpg" class="d-block w-100" id="banner" alt="La casa de papel">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>LA CASA DE PAPEL</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/elite_netflix_anuncia_novos_personagens_e_retorno_de_omar_para_7o_ano_da_serie.jpg" class="d-block w-100" id="banner" alt="Elite">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>ELITE</h5>' +
      '<p>Disponível na NETFLIX</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>',
    livros:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/mafalda-site_canguru-news.jpg" class="d-block w-100" id="banner" alt="Mafalda">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>MAFALDA</h5>' +
      '<p>Disponível no KINDLE</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>',
    instagrans:
      '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">' +
      '<div class="carousel-indicators">' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>' +
      '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>' +
      '</div>' +
      '<div class="carousel-inner">' +
      '<div class="carousel-item active">' +
      '<img src="Assets/Images/bandeira-da-espanha-1.jpg" class="d-block w-100" id="banner" alt="Fuck jerry">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>FUCK JERRY</h5>' +
      '<p>@fuckjerry</p>' +
      '</div>' +
      '</div>' +
      '<div class="carousel-item">' +
      '<img src="Assets/Images/unnamed.png" class="d-block w-100" id="banner" alt="El pais">' +
      '<div class="carousel-caption d-none d-md-block">' +
      '<h5>EL PAÌS</h5>' +
      '<p>@elpais</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">' +
      '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Previous</span>' +
      '</button>' +
      '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">' +
      '<span class="carousel-control-next-icon" aria-hidden="true"></span>' +
      '<span class="visually-hidden">Next</span>' +
      '</button>' +
      '</div>'
  }
};

function load_page(lingua, midia) {
  document.getElementById("content").innerHTML = dados[lingua][midia];
}