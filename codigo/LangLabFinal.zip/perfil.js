btn_editProfile.onclick = () => location.href = 'editarPerfil.html';

function leDados() {
  let strDados = localStorage.getItem('dbs');
  let objDados = {};

  if (strDados) {
    objDados = JSON.parse(strDados);
  }
  else {
    objDados = { Detalhes: [{ usuario: "João da Silva", pNome: "João", uNome: "da Silva", email: "exemplo@ex.com", telefone: "99999999999", nascimento: "00/00/0000" }] };
  }

  return objDados;
}

function imprimeDados() {
  let divUsername = document.getElementById('divUsername');
  let objDados = leDados();
  let strHtml = `<label class="small mb-1" for="inputUsername">Nome de usuário:</label>
    <h1 class="form-control" id="Username" type="text">${objDados.Detalhes[0].usuario}</h1>`;
  divUsername.innerHTML = strHtml;

  divEmail = document.getElementById('divEmail');
  strHtml = `<label class="small mb-1" for="inputEmailAddress">Email: </label>
    <h1 class="form-control" id="EmailAddress" type="email" value="">${objDados.Detalhes[0].email}</h1>`;
  divEmail.innerHTML = strHtml;
}

imprimeDados();

