
//var objDados = {Detalhes: [ {usuario: "João da Silva"}, {pNome: "João"}, {uNome: "da Silva"}, {email: "exemplo@ex.com"}, {telefone: "99999999999"}, {nascimento: "00/00/0000"} ] };
//var objDados = {Detalhes: [ { usuario: "João da Silva", pNome: "João", uNome: "da Silva", email: "exemplo@ex.com", telefone: "99999999999", nascimento: "00/00/0000" } ] };
//console.log(objDados)

function leDadosp() {
  let strDadosp = localStorage.getItem('dbs');
  let objDadosp = {};

  if (strDadosp) {
    objDadosp = JSON.parse(strDadosp);
  }
  else {
    objDadosp = { Detalhes: [{ usuario: "João da Silva", pNome: "João", uNome: "da Silva", email: "exemplo@ex.com", telefone: "99999999999", nascimento: "00/00/0000" }] };
  }

  return objDadosp;
}

console.log(leDadosp())

function preencheDadosp() {
  let objDadosp = leDadosp();
  document.getElementById('inputUsername').value = objDadosp.Detalhes[0].usuario;
  document.getElementById('inputFirstName').value = objDadosp.Detalhes[0].pNome;
  document.getElementById('inputLastName').value = objDadosp.Detalhes[0].uNome;
  document.getElementById('inputEmailAddress').value = objDadosp.Detalhes[0].email;
  document.getElementById('inputPhone').value = objDadosp.Detalhes[0].telefone;
  document.getElementById('inputBirthday').value = objDadosp.Detalhes[0].nascimento;
}

function salvarAlteracoes() {
  let objDadosp = leDadosp();
  objDadosp.Detalhes[0].usuario = document.getElementById('inputUsername').value;
  objDadosp.Detalhes[0].pNome = document.getElementById('inputFirstName').value;
  objDadosp.Detalhes[0].uNome = document.getElementById('inputLastName').value;
  objDadosp.Detalhes[0].email = document.getElementById('inputEmailAddress').value;
  objDadosp.Detalhes[0].telefone = document.getElementById('inputPhone').value;
  objDadosp.Detalhes[0].nascimento = document.getElementById('inputBirthday').value;
  localStorage.setItem('dbs', JSON.stringify(objDadosp));
  location.href = 'perfil.html';

}

preencheDadosp();

// Configura os botões
btn_salvar.onclick = () => salvarAlteracoes();
//document.getElementById ('btn_salvar').addEventListener ('click', salvarAlteracoes);
